export const dados = [{
        id:1,
        nome:"Burguinho",
        descricao: "Pão Brioche, com 100g de carne de fraldinha e duas fatias de queijo cheddar",
        valor: 19.99,
        imagem:"https://static.ifood-static.com.br/image/upload/t_medium/pratos/28c72a6e-ab3a-4e06-b1ea-2f60db2aa2db/202111101502_553B_i.jpg"
    },
    {
        id:2,
        nome:"Buffalo do chef",
        descricao: "Blend de 160g de fraldinha, no pão de batata, queijo cheddar, ovo, bacon e maionese caseira.",
        valor: 26.99,
        imagem:"https://static.ifood-static.com.br/image/upload/t_medium/pratos/28c72a6e-ab3a-4e06-b1ea-2f60db2aa2db/202102021509_hSGm_.jpeg"
    },
    {
        id:3,
        nome: "Delicious crispy",
        descricao:"Blend 180g de alcatra no pão brioche, queijo cheddar, cebola crocante, tiras de bacon e o delicioso molho de requeijão.",
        valor: 31.99,
        imagem:"https://static.ifood-static.com.br/image/upload/t_medium/pratos/28c72a6e-ab3a-4e06-b1ea-2f60db2aa2db/202102021512_WCK5_.jpeg"
    },
    {
        id:4,
        nome:"Buffalo onion rings",
        descricao:"Blend de alcatra com 180g de carne no pão de batata, queijo cheddar, peperoni, ketchp heinz, cebola onion rings e molho de requeijão.",
        valor: 29.00,
        imagem:"https://static.ifood-static.com.br/image/upload/t_medium/pratos/28c72a6e-ab3a-4e06-b1ea-2f60db2aa2db/202102021516_mvuY_.jpeg"
    }];