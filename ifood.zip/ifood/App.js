import App from "./ifood";

export default App;